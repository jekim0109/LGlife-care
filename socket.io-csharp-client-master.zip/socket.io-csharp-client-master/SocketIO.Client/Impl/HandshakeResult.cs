namespace SocketIO.Client.Impl
{
   internal enum HandshakeResult
   {
      Success,
      Error,
      Forbidden
   }
}