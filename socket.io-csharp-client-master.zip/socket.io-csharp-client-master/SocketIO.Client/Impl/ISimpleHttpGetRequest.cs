namespace SocketIO.Client.Impl
{
   internal interface ISimpleHttpGetRequest
   {
      string Execute();
   }
}